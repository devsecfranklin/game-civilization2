CivMGE.zip .txt file
These up dates are meant for those of us looking to have the most updated files for our game. These files are meant for those of us owning a copy of Civilization II, Classic or MGE, not a warez version. This is the first version of the necessary files to update your civ to "classic" 2.7.8 or "mge" 1.7 and as such may cause errors so back up all files which will be changed. Remember Civilization II is trademarked/copyrighted/reserved to Microprose (now owned by Infogrames) and is NOT free for download.

Now you may ask "Why have a 2.7.8 update if its included in MGE?" Well a couple reasons actually. First of all MGE requires that there be A Civ cd in the CD-rom drive, though it does not care which, and I have heard that the scenario creation tools are better in 2.7.8.

Which version should you download? That is up to you. If you have enough space on your computer then I would say both, install civ in 2 different directories. I myself have Civ II 2.42 Civ II 2.78 and Civ II MGE 1.7 on my computer. If you are limited on space I would recommend going with what the people you play games with use, so that your versions are compatible for say sucession games. If you really want my opinion I would say MGE as it is multiplayer.

This is release version Beta 1.4
Beta 1.0: MGE patch didn't work, necessary files now included. (file now over 4x bigger!)
Files included in CivMGE zips:
Civ2.exe
Civ2Maps.exe
Civ2Art.dll
cv.dll
Intro.dll
mk.dll
pv.dll
ss.dll
Tiles.dll
timerdll.dll
Wonder.dll
XDaemon.dll
Uninst.isu
Editoras.gif
Editorpt.gif
Editorsa.gif
Editorsq.gif
Units.gif
Vfwfig.reg
Advice.txt (new)
Alexandr.txt
Civ2fanw.txt
Civ2faq.txt
Council.txt
Debug.txt
Describe.txt
fcredits.txt
Game.txt
Help.txt
Herald.txt
Labels.txt
Leaders.txt
Menu.txt
MGEReadme.txt
Misc.txt
mpcredits.txt
Patch.txt
ReadMe.txt
Readmev13.txt
Rules.txt
Sc.txt
Scredits.txt
Tutorial.txt