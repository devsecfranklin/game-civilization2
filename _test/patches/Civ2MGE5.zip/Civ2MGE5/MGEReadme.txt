*************************************************

Civilization II Multiplayer Gold Edition  Readme.TXT file.
Copyright 1998, MicroProse Software, Inc.

August 20, 1998
Changes, updates, and goodies that didn't 
make it into the manual.

Visit our web site at www.microprose.com for 
up to the minute information and updates.
**************************************************

---------------------------------------------------------------------
WONDERS OF THE WORLD-MULTIPLAYER EFFECTS
---------------------------------------------------------------------
There are three Wonders of the World whose effects reduced
and/or ignored by human opponents in multiplayer games:

* Eiffel Tower: The effects of this Wonder deal entirely with
the attitude of other civilizations. Since the attitude of a human
opponent cannot be regulated, this Wonder has no effect on
other humans in a multiplayer game.

* Great Wall: Human opponents are not forced to offer peace
or a cease-fire during negotiations with the owner of this
Wonder. All other effects of the Great Wall function
normally.

* United Nations: Human opponents are not forced to offer
peace or a cease-fire during negotiations with the owner of this
Wonder. All other effects of the United Nations function
normally.

Note that these three Wonders function normally with regard to
AI-controlled civilizations in multiplayer games.

-------------------------------------------------------------
BREAKING STRATEGIC ALLIANCES IN  
MULTIPLAYER GAMES
-------------------------------------------------------------
In a multiplayer game, human players are not forced to remove their
troops from another human's territory when they break a Strategic
Alliance with that player. In human-A.I. interactions, this situation is
still resolved just as it is in a single player game.

------------------------------------------------------
SPECIAL ADVANCES AND EVENTS IN
MULTIPLAYER SCENARIO PLAY
------------------------------------------------------
All of the scenarios included in Civilization II Multiplayer
Gold Edition can be played in multiplayer mode. It should be
noted, however, that the scenarios were designed for single
player games, and may be quite unbalanced in a multiplayer
environment.

In addition, there are certain scenarios that contain special events 
and/or advances associated with certain civilizations that can potentially
lead to unpredictable results when the scenario is played in multiplayer mode. 
The scenarios (and the affected civilizations therein) include:

* Alien (Hodads)
* Apocalypse (Mutants, New Beetles, Eradicators, Saurians, Kritters)
* Hidden (BON2) (Freaks, Paranoids, Martians, Revolutionaries)
* Ice Planet (All Civilizations)
* Midgard (All Civilizations)
* Samurai (English, Koreans)
* Jules Verne (Exotics, Secret Evil Society)
* X-COM (All Civilizations)

Typical problems associated with special events and advances in these
scenarios include:

* The loss of ability to build a unit type after trading or receiving a
   a special advance.
* Text messages describing inexplicable events.
* Inability to complete the scenario.

These problems are, unfortunately, unavoidable. The only solution is
to avoid these scenarios in multiplayer or refrain from having human
players control the affected civilizations therein.

------------------------------------------------------
A NOTE ON DOUBLE PRODUCTION AND
DOUBLE MOVEMENT IN SCENARIOS
------------------------------------------------------
The double production and double movement options have a 
tendency to unbalance gameplay in certain situations. This is
especially true in scenarios that begin with large civilizations.
For optimum game balance, it is recommended that these options 
not be activated when playing existing scenarios in multiplayer
mode.

-------------------------------------------------------------
SETTING UP ADDITIONAL MAP WINDOWS
-------------------------------------------------------------
By default, the game follows the movements of other civilizations
within your units field of view when it is not your turn. This can
be distracting in multiplayer when you are attempting to manage
your cities or perform other tasks during your opponents' movement
phase.

To circumvent this, you can open an additional map window that
does not track the movement of other civilizations by right-clicking
the World Map.

-------------------------------------------------------------
LOADING SAVED GAMES WITH ALTERNATE
FILE EXTENSIONS
-------------------------------------------------------------
Saved games in Civilization II Multiplayer Gold Edition can have
one of three different file extensions:

* .SAV for single player games
* .HOT for multiplayer hot seat games
* .NET for network and Internet multiplayer games

Saved games of any type can be loaded into any game type, but
the Load Game dialogue defaults to the game type selected. For
example, when Load Game is selected in a single player game, only
the saved games with the extension .SAV are listed even though
you can load .HOT and .NET games as well.

To list games of an alternate type, enter "*." followed by the file
extension for the file type you want to load in the File Type field
of the Load Game dialogue. To list all available files, enter "*.*"
in the File Type field.

-------------------------------------------------------------
LAG TIME DURING INTERNET PLAY
-------------------------------------------------------------
Lag time is an unfortunate reality on the Internet, and cannot be
entirely eliminated. However, if you experience excessive lag time,
make sure your modem is set to its maximum connection speed
and that you have the latest modem drivers from the manufacturer
installed.

-------------------------------------------------------------
SETUP PROCEDURE FOR DIRECT CONNECT  
MULTIPLAYER GAMES
-------------------------------------------------------------
NOTE: Dial-Up networking for this game requires version 1.2 of
Windows 95 Dial-Up networking. If you do not have this update,
you can download it from Microsoft at:

http://www.microsoft.com/windows/downloads/contents/Updates/W95DialUpNetw/default.asp

(This procedure assumes some familiarity with networking and 
Windows components.)

INSTALLING DIAL-UP NETWORKING

Adding the Dial-Up networking component
1. Open the control panel
2. Select Add/Remove Programs
3. Go under the Windows Setup tab
4. In the list of installed Windows components, select the 
   	Communications option
5. While the Communications option is selected, press the 
   	Details button
6. Enable the Dial-Up networking option

You may have to insert Windows disks at this point.  There may 
also be prompts for adding a Dial-Up Adapter.  Answer "yes" to any 
options concerning the addition of such an adapter.

Setup the network protocol
1. Add a Dial-Up adapter if not already present in the list
 	(Add ... Adapter... Manufacturer = Microsoft, 
	Network Adapter =Dial-Up Adapter)
2. Add the TCP/IP protocol to the Dial-Up adapter
 	(Add ... Protocol ... Manufacturer = Microsoft, 
	Protocol = TCP/IP)
3. Select the Dial-Up Adapter in the network adapters list
4. Press the properties button
5. Under the IP Address tab, enter the following information:
	For IP Address, on the first computer, use 100.100.100.1  
	on the second computer, use 100.100.100.2
	For subnet mask, on both computers, use 255.255.255.0
6.	Ensure that File and Print Sharing for Microsoft Networking is
	installed.  To install it, add a new service (Service...Microsoft.)
	This cannot exist with File and Print Sharing for Netware Networks, 
	so remove any sharing for Netware which may be present.

 
AFTER DIAL-UP NETWORKING IS INSTALLED

One of the two computers is the Dial-Up networking server, and one 
is the client

The Server:
1. Double-click the My Computer icon, and then double-click 
	Dial-Up Networking.
2. On the Connections menu, click Dial-Up Server.
3. Click Allow Caller Access.
4. If you want to assign a password so that only those who know the 
	password can dial into your computer, click Change Password.
5. Click Server Type.
6. Click the PPP server type from the Type of Dial-Up Server list, and 
	then click OK.

***Tips***
Before setting up your computer as a Dial-Up Networking server, you must 
set up a modem. For Help on an item, click  at the top of the dialog box, 
and then click the item.

The Client:

1. Double-click the My Computer icon, and then double-click Dial-Up 
	Networking.
2. Follow the instructions on the screen.
3. Once the new session is created, an icon will be placed in the Dial-Up 
	Networking folder.  You may use this to connect to the 
	remote computer.

***Notes***
If you have already set up one or more Dial-Up connections, you can 
double-click Make New Connection to create a new connection. To dial a 
connection that you have already set up, double-click its icon in the Dial-Up 
Networking window. After you have connected to another computer, you 
can start a TCP/IP-based network game. The network IP addresses will be 
100.100.100.1 and 100.100.100.2. If you do not see a Dial-Up Networking 
folder in My Computer, then it is not installed. Follow the directions on page 1.


-------------------------------------------------------------
Compact Install
-------------------------------------------------------------
Sound files and scenarios are NOT installed when the compact 
install is selected.

-------------------------------------------------------------
Correction to Manual: Map Editor
-------------------------------------------------------------
The "Special" tool and the "City" tool are switched in the manual.

-------------------------------------------------------------
Customizing the Domestic Advisor's City Improvement Picks
-------------------------------------------------------------
You may customize the domestic advisor's city improvement picks for
the autobuild if you wish.  Create a file in your Civ2 directory
called CITYPREF.TXT.  The first line should be:

@AUTOBUILD

Each succeeding line contains the name of a city improvement in the
order you want to build them. You don't have to list every city
improvement, but each improvement must be spelled -exactly- as it is
in RULES.TXT (foreign language versions use the exact spelling from
RULES.FRE or RULES.GER as appropriate). Domestic advisor will then
choose improvements from this list provided technology is available and
city is otherwise eligible to build them. If nothing on list is available,
advisor resorts to his normal algorithm.

The military advisor will make his picks as usual. However, you can order
him never to build "defensive" type units by inserting the line @NODEFEND
at the beginning or end of the CITYPREF.TXT file (don't put it between
the @AUTOBUILD line and the list of improvements).

An example file below:

@NODEFEND
@AUTOBUILD
Temple
Marketplace
Library

The file is re-read every time you click the "AUTO" button on the "What
shall we build?" menu, so if you wish you can alter your priorities over
the course of a game without reloading.

-------------------------------------------------------------
Rising Maintenance Cost for Barracks
-------------------------------------------------------------
The maintenance cost for the Barracks improvement increases by one gold 
each time it is rendered obsolete by a civilization advance.   When 
first constructed the cost is one gold.  After the discovery of Gunpowder 
and the Barracks is rebuilt it costs two gold.  Finally, after the 
discovery of Mobile Warfare and the Barracks is rebuilt the cost is 
three gold.
